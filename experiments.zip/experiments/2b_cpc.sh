echo 'exp2b cp 0' 
./target/release/broccoli --env cpc --depth 2 --num-nodes 3 --num-iters 10000 --action-policy none --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -0.211 -0.156 -0.138 -0.100 -0.036 -0.031 -0.030 0.003 0.073 0.800  > TD3_acts_cpc_s=0.txt
echo 'exp2b cp 1' 
./target/release/broccoli --env cpc --depth 2 --num-nodes 3 --num-iters 10000 --action-policy none --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -0.577 -0.037 -0.019 -0.015 -0.003 -0.001 0.011 0.016 0.017 0.793  > TD3_acts_cpc_s=1.txt
echo 'exp2b cp 2' 
./target/release/broccoli --env cpc --depth 2 --num-nodes 3 --num-iters 10000 --action-policy none --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -0.603 -0.007 -0.003 -0.002 -0.002 -0.000 0.016 0.020 0.051 0.710  > TD3_acts_cpc_s=2.txt
echo 'exp2b cp 3' 
./target/release/broccoli --env cpc --depth 2 --num-nodes 3 --num-iters 10000 --action-policy none --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -0.656 -0.376 -0.108 -0.066 -0.003 -0.003 -0.003 0.024 0.264 0.643  > TD3_acts_cpc_s=3.txt
echo 'exp2b cp 4' 
./target/release/broccoli --env cpc --depth 2 --num-nodes 3 --num-iters 10000 --action-policy none --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -0.596 -0.300 -0.018 -0.004 -0.004 0.002 0.018 0.028 0.349 0.732  > TD3_acts_cpc_s=4.txt
