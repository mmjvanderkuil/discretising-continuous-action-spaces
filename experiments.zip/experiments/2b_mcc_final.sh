echo 'exp2a mcc final' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -0.160 -0.100 -0.050 0.000 0.030 0.060 0.100 0.320 0.420 0.660 0.740  > small_trees_mcc_final.txt
