echo "Uniform actions:"
echo "Actions: [-1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1
echo "Actions: [-1 -0.75 -0.5 -0.25 0.25 0.5 0.75 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1 -0.75 -0.5 -0.25 0.25 0.5 0.75 1
echo "Actions: [-1 -0.66 -0.33 0 0.33 0.66 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1 -0.66 -0.33 0 0.33 0.66 1
echo "Actions: [-1 -0.66 -0.33 0.33 0.66 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1 -0.66 -0.33 0.33 0.66 1
echo "Actions: [-1.0 -0.5 0 0.5 1.0]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1.0 -0.5 0 0.5 1.0
echo "Actions: [-1.0 -0.5 0.5 1.0]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1.0 -0.5 0.5 1.0