echo "Geometric Progression actions:"
echo "Actions: [-1  -0.5  -0.25  -0.125 0 0.125 0.25 0.5 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --action-policy none --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1  -0.5  -0.25  -0.125 0 0.125 0.25 0.5 1 > geo_prog_mcc_real.txt

echo "Geometric Progression actions:"
echo "Actions: [-1  -0.5  -0.25  -0.125 0 0.125 0.25 0.5 1]"
cargo run --release -- --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --action-policy none --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -1  -0.5  -0.25 -0.125 0 0.125 0.25 0.5 1 > geo_prog_cpc_real.txt

echo "Geometric Progression actions:"
echo "Actions: [-2 -1.5 -1 -0.5 0 0.5 1 1.5 2]"
cargo run --release -- --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 1 --actions -2 -1 -0.5  -0.25 0 0.25 0.5 1 2 > geo_prog_penc_real.txt

