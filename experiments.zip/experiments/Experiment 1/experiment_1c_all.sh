echo "Geometric Regression actions:"
echo "Actions: [-1  -0.875 -0.75 -0.5 0 0.5 0.75 0.875 1]"
cargo run --release -- --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --action-policy none --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1  -0.875 -0.75 -0.5 0 0.5 0.75 0.875 1 > geo_regr_mcc.txt

echo "Geometric Regression actions:"
echo "Actions: [-1  -0.875 -0.75 -0.5 0 0.5 0.75 0.875 1]"
cargo run --release -- --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --action-policy none --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 1 --actions -1  -0.875 -0.75 -0.5 0 0.5 0.75 0.875 1 > geo_regr_cpc.txt

echo "Geometric Regression actions:"
echo "Actions: [-2 -1.75 -1.5 -1 0 1 1.5 1.75 2]"
cargo run --release -- --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 1 --actions -2 -1.75 -1.5 -1 0 1 1.5 1.75 2 > geo_regr_penc.txt
