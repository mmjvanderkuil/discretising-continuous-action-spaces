echo 'exp2a penc0'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -1.440 -1.400 -0.520 0.160 0.600 0.980  > small_tree_penc_s=0.txt
echo 'exp2a penc1'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -1.280 -1.240 -1.160 0.360 0.690 1.250  > small_tree_penc_s=1.txt
echo 'exp2a penc2'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -0.780 -0.650 -0.270 0.480 0.610 1.300  > small_tree_penc_s=2.txt
echo 'exp2a penc3'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -1.480 -0.970 -0.870 0.070 0.810 1.030  > small_tree_penc_s=3.txt
echo 'exp2a penc4'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -1.150 -0.910 -0.780 0.320 0.970 1.300  > small_tree_penc_s=4.txt
echo 'exp2a penc5'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -1.600 -1.290 -0.650 0.100 1.630 1.910  > small_tree_penc_s=5.txt
echo 'exp2a penc6'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -0.970 -0.470 -0.030 0.670 1.010 1.740  > small_tree_penc_s=6.txt
echo 'exp2a penc7'
 ./target/release/broccoli --env penc --depth 2 --num-nodes 3 --num-iters 100 --action-policy none --predicate-increment 0.1 0.1 --initial-state-values 0.5 0 --predicate-reasoning 1 --actions -0.830 -0.760 -0.310 0.030 0.410 0.780  > small_tree_penc_s=7.txt
