echo "Uniform actions:"
echo "Actions: [-1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1
echo "Actions: [-1 -0.75 -0.5 -0.25  0.25 0.5 0.75 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.75 -0.5 -0.25  0.25 0.5 0.75 1
echo "Actions: [-1 -0.66 -0.33 0 0.33 0.66 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.66 -0.33 0 0.33 0.66 1
echo "Actions: [-1 -0.66 -0.33 0.33 0.66 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.66 -0.33  0.33 0.66 1
echo "Actions: [-1 -0.5 0 0.5 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.5 0 0.5  1
echo "Actions: [-1 -0.5 0.5 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.5 0.5 1
