echo "Restoring lost files:"
echo "MCC environment:\n"
echo "Actions: [-1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1]"
./target/release/broccoli --env mcc --depth 2 --num-nodes 6 --num-iters 1000 --predicate-increment 0.1 0.014 --action-policy none --initial-state-values -0.5 0.0 --predicate-reasoning 0 --actions -1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1
echo "CPC environment:\n"
echo "Actions: [-1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --action-policy none --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1
echo "Actions: [-1 -0.5 0.5 1]"
./target/release/broccoli --env cpc --depth 2 --num-nodes 6 --num-iters 100000 --predicate-increment 0.1 0.1 0.05 0.1 --action-policy none --initial-state-values -0.05 0.05 0.05 0.05 --predicate-reasoning 0 --actions -1 -0.5 0.5 1
echo "PenC environemnt:\n"
echo "Actions: [-2 -1 1 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1  1 2
echo "\n\n----Done----\n-Save to Zip-\n\n"