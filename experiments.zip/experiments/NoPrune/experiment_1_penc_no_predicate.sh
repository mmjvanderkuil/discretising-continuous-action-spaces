echo "Uniform actions:"
echo "Actions: [-2 -1.5 -1 -0.5 0 0.5 1 1.5 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1.5 -1 -0.5 0 0.5 1 1.5 2
echo "Actions: [-1 -0.75 -0.5 -0.25 0.25 0.5 0.75 1]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1.5 -1 -0.5 0.5 1 1.5 2
echo "Actions: [-2 -1.33 -0.66 0 0.66 1.33 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1.33 -0.66 0 0.66 1.33 2
echo "Actions: [-2 -1.33 -0.66 0.66 1.33 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1.33 -0.66 0.66 1.33 2
echo "Actions: [-2 -1 0 1 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1  0 1 2
echo "Actions: [-2 -1 1 2]"
./target/release/broccoli --env penc --depth 2 --num-nodes 6 --num-iters 100 --predicate-increment 0.1 0.1 --action-policy none --initial-state-values 0.5 0.0 --predicate-reasoning 0 --actions -2 -1  1 2
