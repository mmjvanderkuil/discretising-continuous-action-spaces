echo 'exp2a mcc 0' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions 0.018 0.018 0.034 0.042 0.060 0.067 0.073 0.074  > TD3_acts_mcc_s=0.txt
echo 'exp2a mcc 1' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions 0.005 0.013 0.026 0.033 0.047 0.049 0.053 0.057  > TD3_acts_mcc_s=1.txt
echo 'exp2a mcc 2' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -0.005 0.007 0.007 0.026 0.027 0.028 0.038 0.077  > TD3_acts_mcc_s=2.txt
echo 'exp2a mcc 3' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -0.008 0.022 0.024 0.029 0.036 0.050 0.051 0.074  > TD3_acts_mcc_s=3.txt
echo 'exp2a mcc 4' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions 0.001 0.017 0.022 0.023 0.024 0.031 0.031 0.060  > TD3_acts_mcc_s=4.txt
