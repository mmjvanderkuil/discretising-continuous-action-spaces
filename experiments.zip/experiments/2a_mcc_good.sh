echo 'exp2b mcc 0' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions -1.000000 1.000000  > TD3_acts_mcc_s=0.txt
echo 'exp2b mcc 1' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions  -1.000000 -0.999990 -0.989322 -0.476697 1.000000  > TD3_acts_mcc_s=1.txt
echo 'exp2b mcc 2' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions  -1.000000 -0.994739 1.000000  > TD3_acts_mcc_s=2.txt
echo 'exp2b mcc 3' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions  -1.000000 -0.941970 0.847655 1.000000  > TD3_acts_mcc_s=3.txt
echo 'exp2b mcc 4' 
./target/release/broccoli --env mcc --depth 2 --num-nodes 3 --num-iters 1000 --action-policy none --predicate-increment 0.1 0.014 --initial-state-values -0.5 0.0 --predicate-reasoning 1 --actions  -1.000000 -0.999977 -0.995889 1.000000  > TD3_acts_mcc_s=4.txt
